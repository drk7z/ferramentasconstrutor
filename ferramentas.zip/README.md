# Sistema de Gerenciamento de Usuários

Um sistema completo de gerenciamento de usuários desenvolvido em PHP com interface responsiva usando Bootstrap 5.

## 📋 Funcionalidades

- **Autenticação de Usuários**: Login seguro com geração de tokens de autenticação
- **Cadastro de Usuários**: Formulário de criação de contas com validação
- **Recuperação de Senha**: Sistema de recuperação de senha por e-mail
- **Gerenciamento de Usuários**: Interface para visualizar, editar e deletar usuários
- **Dashboard Administrativo**: Painel principal com métricas e navegação
- **Design Responsivo**: Interface adaptável para dispositivos móveis e desktop
- **Proteção de Sessão**: Sistema de segurança com validação de tokens

## 🛠️ Tecnologias Utilizadas

- **Backend**: PHP 7+
- **Banco de Dados**: MySQL
- **Frontend**: HTML5, CSS3, JavaScript
- **Framework CSS**: Bootstrap 5.3.0
- **Ícones**: Font Awesome 6.0.0

## 📁 Estrutura do Projeto

```
/
├── index.php              # Página principal (Dashboard)
├── login/
│   ├── login.php          # Página de login
│   ├── signup.php         # Página de cadastro
│   ├── recover.php        # Página de recuperação de senha
│   ├── logout.php         # Script de logout
│   ├── edit_users.php     # Gerenciamento de usuários
│   ├── edit_user.php      # Edição individual de usuário
│   ├── config.php         # Configuração do banco de dados
│   ├── database.sql       # Script de criação do banco
│   ├── styles.css         # Estilos personalizados
│   ├── script.js          # JavaScript para login
│   ├── recover.js         # JavaScript para recuperação
│   └── signup.js          # JavaScript para cadastro
└── README.md              # Este arquivo
```

## 🚀 Instalação e Configuração

### Pré-requisitos

- Servidor web (Apache/Nginx)
- PHP 7.0 ou superior
- MySQL 5.7 ou superior
- **Visual C++ Redistributable** (obrigatório para PHP no Windows)
- Navegador web moderno

### Passos de Instalação

1. **Clone ou baixe o projeto** para o diretório raiz do seu servidor web

2. **Configure o banco de dados**:
   - Crie um banco de dados MySQL chamado `login-teste`
   - Execute o script `login/database.sql` para criar a tabela `users`

3. **Configure a conexão**:
   - Edite o arquivo `login/config.php`
   - Atualize as credenciais do banco de dados se necessário

4. **Permissões**:
   - Certifique-se de que o servidor web tem permissões de leitura/escrita nos arquivos

## 📖 Como Usar

### Como Executar Localmente

Para executar o website localmente no Windows, siga estes passos:

1. **Instale o PHP e MySQL** (se não tiver):
   - **Recomendado**: Baixe e instale o XAMPP (https://www.apachefriends.org/) que inclui Apache, PHP e MySQL
     - Instale no local padrão: `C:\xampp`
     - O script `run_app.bat` detectará automaticamente o XAMPP e usará seus executáveis
   - **Ou instale separadamente**:
     - PHP: `choco install php` (via Chocolatey)
     - MySQL: `choco install mysql` (via Chocolatey)
   - **Verificação**: Abra o terminal e execute `php -v` e `mysql -V` para confirmar que estão no PATH

2. **Execute Tudo Automaticamente** (usando o executável):
   - Execute o arquivo `run_app.bat` (duplo clique) para configurar o banco de dados, iniciar o servidor e abrir o navegador automaticamente
   - Ou manualmente:
     - Configure o banco:
       ```
       mysql -u admin -padmin
       CREATE DATABASE login-teste;
       exit;
       mysql -u admin -padmin login-teste < login/database.sql
       ```
       **Nota:** O usuário MySQL deve ser "admin" com senha "admin"
     - Inicie o servidor: Abra o terminal no diretório raiz (c:/vscode) e execute `php -S localhost:8000`
     - Abra o navegador em http://localhost:8000/index.php

3. **Acesse o Website**:
   - O site estará disponível em http://localhost:8000/index.php
   - O executável `run_app.bat` faz tudo automaticamente

4. **Parar o Servidor**:
   - Execute o arquivo `stop_server.bat` (duplo clique) para parar o servidor PHP e fechar conexões
   - Os dados são salvos automaticamente no banco de dados

### Navegação no Sistema

1. **Acesse o sistema**:
   - Abra seu navegador e vá para `http://localhost:8000/index.php`

2. **Login**:
   - Se não estiver logado, será redirecionado para `login/login.php`
   - Use credenciais válidas ou crie uma nova conta

3. **Navegação**:
   - Use o menu superior para navegar entre seções
   - Dashboard: Visão geral do sistema
   - Usuários: Gerenciamento de contas
   - Configurações: (Em desenvolvimento)

4. **Gerenciamento de Usuários**:
   - Acesse "Editar" no menu Usuários
   - Visualize a lista de usuários
   - Clique em "Editar" para modificar dados
   - Use "Deletar" para remover usuários

## 🔐 Segurança

- Senhas criptografadas com `password_hash()`
- Tokens de autenticação únicos por sessão
- Validação de sessão em todas as páginas protegidas
- Proteção contra acesso não autorizado
- **Timeout automático de sessão**: 45 minutos de inatividade
- **Salvamento automático de dados**: Todas as alterações são salvas automaticamente no banco de dados

## 📱 Responsividade

O sistema é totalmente responsivo e funciona bem em:
- Desktop (1920px+)
- Tablet (768px - 1199px)
- Mobile (até 767px)

## 🐛 Solução de Problemas

### Problemas Comuns

1. **'mysql' não é reconhecido como comando**:
   - Instale o MySQL ou XAMPP
   - Adicione o MySQL ao PATH do sistema
   - Execute `mysql -V` no terminal para verificar

2. **'php' não é reconhecido como comando**:
   - Instale o PHP ou XAMPP
   - Adicione o PHP ao PATH do sistema
   - Execute `php -v` no terminal para verificar

3. **Erro de conexão com banco de dados**:
   - Verifique as credenciais em `config.php`
   - Certifique-se de que o MySQL está rodando

4. **Página não carrega**:
   - Verifique se o PHP está instalado e configurado
   - Confirme as permissões dos arquivos

5. **Login não funciona**:
   - Verifique se a tabela `users` foi criada
   - Confirme se há usuários cadastrados

## 🤝 Contribuição

Para contribuir com o projeto:

1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 📞 Suporte

Para suporte ou dúvidas:
- Abra uma issue no repositório
- Verifique a documentação no código
- Consulte os logs de erro do servidor

---

**Desenvolvido com ❤️ usando PHP e Bootstrap**
