<?php
session_start();

// Salvar dados da sessão antes de destruir (se necessário)
// Os dados no banco são automaticamente salvos pelo MySQL

// Clear authentication token cookie
setcookie('auth_token', '', time() - 3600, "/");

// Destruir sessão
session_destroy();

// Redirecionar para login com mensagem de logout
header("Location: login.php?message=Logout realizado com sucesso. Dados salvos automaticamente.");
exit();
?>
