<?php
// Configuração de sessão com timeout de 45 minutos
ini_set('session.gc_maxlifetime', 2700); // 45 minutos em segundos
ini_set('session.cookie_lifetime', 2700); // 45 minutos para o cookie

session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Verificar timeout de inatividade
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 2700)) {
    // Sessão expirou, fazer logout
    session_unset();
    session_destroy();
    setcookie('auth_token', '', time() - 3600, "/");
    header("Location: login.php?message=Sessão expirada por inatividade");
    exit();
}

// Atualizar timestamp da última atividade
$_SESSION['last_activity'] = time();
?>
