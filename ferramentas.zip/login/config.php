<?php
$servername = "localhost";
$username = "admin";
$password = "admin";
$dbname = "login_teste";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
